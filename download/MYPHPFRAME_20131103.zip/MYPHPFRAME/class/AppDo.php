<?php
/**
 * 应用处理基类
 * 
 * @since  2010-1-1
 * @author Wu ZeTao <578014287@qq.com>
 */
Class AppDo Extends AppClass {

    /**
     * 构造函数
     */
    public function __construct() {
        parent::__construct();
    }
    
}

?>