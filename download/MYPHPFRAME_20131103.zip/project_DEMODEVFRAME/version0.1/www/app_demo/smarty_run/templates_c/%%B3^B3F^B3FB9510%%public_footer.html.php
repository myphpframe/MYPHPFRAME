<?php /* Smarty version 2.6.27, created on 2013-09-02 15:59:24
         compiled from public_footer.html */ ?>
</html>