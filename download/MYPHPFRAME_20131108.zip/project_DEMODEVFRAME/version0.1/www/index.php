<?php

header("Location:app_demo/MainHome.php");

?>