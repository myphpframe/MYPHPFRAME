<?php

/* DEMO模块翻译 */
$mpf_lang_demo = array (
    'demo_test' => '测试翻译'
);

?>