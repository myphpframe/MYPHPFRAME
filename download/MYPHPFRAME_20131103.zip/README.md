MYPHPFRAME
==========

MYPHPFRAME--OPEN &amp;&amp; FREE,PHP FRAME &amp;&amp; SOFTWARE!

You should download the package from the download folder( https://github.com/myphpframe/MYPHPFRAME/tree/master/download ),since github has some character encoding issues when packing the files.